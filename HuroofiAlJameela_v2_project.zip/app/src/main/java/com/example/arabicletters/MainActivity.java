package com.example.arabicletters;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private TextToSpeech tts;
    private int index = 0;
    private int stars = 0;
    private final String[] praise = {
        "أحسنت يا محمد! 🌟",
        "محمد بطل! 🏆",
        "يا سلام يا حمودي! 👏",
        "رائع يا بطل! ⭐",
        "ممتاز يا محمد! 🎉",
        "أنت شاطر يا حمودي! 💙"
    };
    private final String[][] data = {
        {"أ","ألف","أرنب","🐰"},{"ب","باء","بطة","🦆"},{"ت","تاء","تفاحة","🍎"},{"ث","ثاء","ثعلب","🦊"},
        {"ج","جيم","جمل","🐪"},{"ح","حاء","حصان","🐴"},{"خ","خاء","خروف","🐑"},{"د","دال","دب","🐻"},
        {"ذ","ذال","ذئب","🐺"},{"ر","راء","رمان","🍎"},{"ز","زاي","زهرة","🌸"},{"س","سين","سمكة","🐟"},
        {"ش","شين","شمس","☀️"},{"ص","صاد","صقر","🦅"},{"ض","ضاد","ضفدع","🐸"},{"ط","طاء","طائرة","✈️"},
        {"ظ","ظاء","ظبي","🦌"},{"ع","عين","عنب","🍇"},{"غ","غين","غزال","🦌"},{"ف","فاء","فيل","🐘"},
        {"ق","قاف","قمر","🌙"},{"ك","كاف","كتاب","📚"},{"ل","لام","ليمون","🍋"},{"م","ميم","موز","🍌"},
        {"ن","نون","نحلة","🐝"},{"ه","هاء","هلال","🌙"},{"و","واو","وردة","🌹"},{"ي","ياء","يد","✋"}
    };

    int dp(float x){ return (int)(x * getResources().getDisplayMetrics().density + .5f); }
    TextView tv(String s,float size,int color){
        TextView v=new TextView(this);
        v.setText(s); v.setTextSize(size); v.setTextColor(color); v.setGravity(Gravity.CENTER);
        v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }
    GradientDrawable bg(int c,float r){
        GradientDrawable g=new GradientDrawable();
        g.setColor(c); g.setCornerRadius(dp(r)); return g;
    }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        tts=new TextToSpeech(this, status -> {
            if(status==TextToSpeech.SUCCESS) tts.setLanguage(new Locale("ar","SA"));
        });
        showHome();
    }

    void speak(String s){
        if(tts!=null) tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, "arabic");
    }

    TextView avatar(){
        TextView a=tv("👦",50,Color.WHITE);
        a.setBackground(bg(Color.WHITE,60));
        return a;
    }

    void showHome(){
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(18),dp(18),dp(18),dp(18));
        root.setBackground(bg(Color.rgb(246,241,255),0));

        TextView title=tv("🌈 حروفي الجميلة",32,Color.rgb(75,45,145));
        root.addView(title,new LinearLayout.LayoutParams(-1,dp(65)));

        TextView sub=tv("تعلم الحروف العربية بطريقة ممتعة ✨",18,Color.rgb(90,75,115));
        root.addView(sub,new LinearLayout.LayoutParams(-1,dp(42)));

        LinearLayout childRow=new LinearLayout(this); childRow.setGravity(Gravity.CENTER);
        ImageView photo=new ImageView(this);
        photo.setImageResource(com.example.arabicletters.R.drawable.mohammed_1);
        photo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        photo.setBackground(bg(Color.WHITE,100)); photo.setClipToOutline(true);
        childRow.addView(photo,new LinearLayout.LayoutParams(dp(115),dp(115)));
        TextView welcome=tv("أهلًا يا محمد! 👋\nجاهز نتعلم ونلعب؟",21,Color.rgb(65,55,95));
        childRow.addView(welcome,new LinearLayout.LayoutParams(dp(230),dp(115)));
        root.addView(childRow,new LinearLayout.LayoutParams(-1,dp(130)));

        Button learn=button("🔤  تعلّم الحروف",Color.rgb(72,145,230));
        Button game=button("🎮  ألعاب الحروف",Color.rgb(157,95,215));
        Button voice=button("🎤  تحدث وتعلّم",Color.rgb(241,111,151));
        Button write=button("✏️  اكتب وتعلّم",Color.rgb(244,166,62));

        root.addView(learn,wide());
        root.addView(game,wide());
        root.addView(voice,wide());
        root.addView(write,wide());

        TextView star=tv("⭐ نجومي اليوم: "+stars,18,Color.rgb(85,65,125));
        root.addView(star,new LinearLayout.LayoutParams(-1,dp(48)));

        learn.setOnClickListener(v->showLearn());
        game.setOnClickListener(v->showGame());
        voice.setOnClickListener(v->startVoice());
        write.setOnClickListener(v->showWrite());

        setContentView(root);
    }

    LinearLayout.LayoutParams wide(){
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(58));
        p.setMargins(0,dp(6),0,dp(6)); return p;
    }
    Button button(String text,int color){
        Button b=new Button(this); b.setText(text); b.setTextSize(19); b.setAllCaps(false);
        b.setTextColor(Color.WHITE); b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        b.setBackground(bg(color,28)); return b;
    }

    void header(LinearLayout root,String title){
        LinearLayout bar=new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL);
        Button back=button("↩",Color.rgb(100,80,150));
        bar.addView(back,new LinearLayout.LayoutParams(dp(58),dp(55)));
        TextView t=tv(title,25,Color.rgb(75,45,145));
        bar.addView(t,new LinearLayout.LayoutParams(0,dp(55),1));
        TextView s=tv("⭐ "+stars,17,Color.rgb(110,80,150));
        bar.addView(s,new LinearLayout.LayoutParams(dp(70),dp(55)));
        root.addView(bar,new LinearLayout.LayoutParams(-1,dp(62)));
        back.setOnClickListener(v->showHome());
    }

    void showLearn(){
        LinearLayout root=base();
        header(root,"🔤 تعلّم الحروف");
        TextView progress=tv((index+1)+" / "+data.length,15,Color.DKGRAY);
        root.addView(progress,new LinearLayout.LayoutParams(-1,dp(30)));

        TextView letter=tv(data[index][0],108,Color.rgb(65,100,220));
        letter.setBackground(bg(Color.WHITE,36)); letter.setElevation(dp(8));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(185));
        p.setMargins(0,dp(3),0,dp(10)); root.addView(letter,p);

        TextView name=tv(data[index][1],27,Color.rgb(60,50,80));
        root.addView(name,new LinearLayout.LayoutParams(-1,dp(45)));

        TextView pic=tv(data[index][3],86,Color.BLACK);
        pic.setBackground(bg(Color.rgb(255,245,214),35)); pic.setElevation(dp(4));
        p=new LinearLayout.LayoutParams(-1,dp(155)); p.setMargins(0,dp(4),0,dp(6)); root.addView(pic,p);

        TextView word=tv(data[index][2],28,Color.rgb(60,80,110));
        root.addView(word,new LinearLayout.LayoutParams(-1,dp(45)));

        LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER);
        Button hear=button("🔊 اسمع",Color.rgb(85,190,135));
        Button prev=button("⬅ السابق",Color.rgb(115,145,210));
        Button next=button("التالي ➡",Color.rgb(115,145,210));
        row.addView(prev,new LinearLayout.LayoutParams(0,dp(58),1));
        row.addView(hear,new LinearLayout.LayoutParams(0,dp(58),1));
        row.addView(next,new LinearLayout.LayoutParams(0,dp(58),1));
        root.addView(row,new LinearLayout.LayoutParams(-1,dp(70)));

        View.OnClickListener hearIt=v->speak(data[index][1]+"... "+data[index][2]);
        letter.setOnClickListener(hearIt); pic.setOnClickListener(hearIt); hear.setOnClickListener(hearIt);
        next.setOnClickListener(v->{index=(index+1)%data.length; showLearn(); speak(data[index][1]);});
        prev.setOnClickListener(v->{index=(index-1+data.length)%data.length; showLearn();});
        setContentView(root);
    }

    LinearLayout base(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL); root.setPadding(dp(16),dp(12),dp(16),dp(12));
        root.setBackground(bg(Color.rgb(246,241,255),0)); return root;
    }

    void showGame(){
        final int target=index;
        LinearLayout root=base(); header(root,"🎮 اختر الحرف الصحيح");
        TextView q=tv("أي حرف يبدأ به هذا الشيء؟",22,Color.rgb(75,55,100));
        root.addView(q,new LinearLayout.LayoutParams(-1,dp(50)));
        TextView obj=tv(data[target][3],95,Color.BLACK); obj.setBackground(bg(Color.WHITE,35));
        root.addView(obj,new LinearLayout.LayoutParams(-1,dp(190)));
        TextView hint=tv(data[target][2],24,Color.rgb(70,85,115));
        root.addView(hint,new LinearLayout.LayoutParams(-1,dp(48)));

        ArrayList<Integer> choices=new ArrayList<>();
        choices.add(target);
        while(choices.size()<3){
            int r=new Random().nextInt(data.length);
            if(!choices.contains(r)) choices.add(r);
        }
        Collections.shuffle(choices);
        LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER);
        for(int c:choices){
            Button b=button(data[c][0],Color.rgb(112,145,230)); b.setTextSize(30);
            row.addView(b,new LinearLayout.LayoutParams(0,dp(75),1));
            b.setOnClickListener(v->{
                if(c==target){ stars++; speak(praise[new Random().nextInt(praise.length)]); Toast.makeText(this,praise[new Random().nextInt(praise.length)],Toast.LENGTH_SHORT).show(); showGame(); }
                else { speak("حاول مرة أخرى يا حمودي"); Toast.makeText(this,"حاول مرة أخرى يا حمودي 💪",Toast.LENGTH_SHORT).show(); }
            });
        }
        root.addView(row,new LinearLayout.LayoutParams(-1,dp(90)));
        Button next=button("سؤال جديد ⭐",Color.rgb(241,166,62)); root.addView(next,wide());
        next.setOnClickListener(v->{index=(index+1)%data.length; showGame();});
        setContentView(root);
    }

    void showWrite(){
        LinearLayout root=base(); header(root,"✏️ اكتب وتعلّم");
        TextView inst=tv("تتبع الحرف بإصبعك ثم جرّب كتابته ✨",21,Color.rgb(70,60,95));
        root.addView(inst,new LinearLayout.LayoutParams(-1,dp(60)));
        TextView letter=tv(data[index][0],115,Color.rgb(160,130,210));
        letter.setBackground(bg(Color.WHITE,40)); root.addView(letter,new LinearLayout.LayoutParams(-1,dp(260)));
        TextView msg=tv("اضغط على الحرف لسماع اسمه 🔊",19,Color.DKGRAY);
        root.addView(msg,new LinearLayout.LayoutParams(-1,dp(55)));
        Button done=button("أنهيت! ⭐",Color.rgb(85,190,135)); root.addView(done,wide());
        letter.setOnClickListener(v->speak(data[index][1]));
        done.setOnClickListener(v->{stars++; speak("أحسنت يا محمد! محمد بطل!"); Toast.makeText(this,"أحسنت يا محمد! محمد بطل! 🌟",Toast.LENGTH_SHORT).show(); showHome();});
        setContentView(root);
    }

    void startVoice(){
        try{
            Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"ar-SA");
            i.putExtra(RecognizerIntent.EXTRA_PROMPT,"قل حرف "+data[index][1]);
            startActivityForResult(i,77);
        }catch(Exception e){ Toast.makeText(this,"التعرف على الصوت غير متاح على هذا الجهاز",Toast.LENGTH_LONG).show(); }
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent dataIntent){
        super.onActivityResult(requestCode,resultCode,dataIntent);
        if(requestCode==77 && resultCode==RESULT_OK && dataIntent!=null){
            ArrayList<String> r=dataIntent.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            String heard=(r!=null && !r.isEmpty())?r.get(0):"";
            String expected=data[index][0]+" "+data[index][1];
            if(heard.contains(data[index][0]) || heard.contains(data[index][1])){
                stars++;
                speak("أحسنت يا محمد! محمد بطل!");
                Toast.makeText(this,"أحسنت يا محمد! محمد بطل! ⭐",Toast.LENGTH_LONG).show();
            }else{
                speak("قريب يا حمودي! حاول مرة ثانية");
                Toast.makeText(this,"قريب يا حمودي! حاول مرة ثانية 💪",Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override protected void onDestroy(){
        if(tts!=null){tts.stop();tts.shutdown();}
        super.onDestroy();
    }
}
